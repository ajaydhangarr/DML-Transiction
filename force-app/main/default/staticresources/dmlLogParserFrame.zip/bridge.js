/* global window, Worker */
(function () {
    'use strict';

    const CHANNEL = 'DML_LOG_PARSER_FRAME_V1';

    // A Salesforce static resource can be served from a different CDN origin
    // than the Lightning page that embeds it. The frame origin is therefore
    // not necessarily the parent origin. Prefer the embedding page's origin
    // from the referrer and learn it from the first parent message when the
    // browser does not provide a referrer.
    function getReferrerOrigin() {
        try {
            return document.referrer ? new URL(document.referrer).origin : null;
        } catch {
            return null;
        }
    }

    let parentOrigin = getReferrerOrigin();
    let parserWorker = null;
    let activeRequestId = null;

    function send(message) {
        window.parent.postMessage({ channel: CHANNEL, ...message }, parentOrigin || '*');
    }

    function isParentMessage(event) {
        if (event.source !== window.parent) return false;
        if (parentOrigin && event.origin !== parentOrigin) return false;
        if (!parentOrigin && event.origin) parentOrigin = event.origin;
        return true;
    }

    function destroyWorker() {
        if (parserWorker) parserWorker.terminate();
        parserWorker = null;
        activeRequestId = null;
    }

    function createWorker() {
        if (parserWorker) return parserWorker;

        const worker = new Worker('./dmlLogWorker.js');
        worker.onmessage = (event) => {
            const message = event.data || {};
            if (message.type === 'READY') return;
            send(message);
            if (message.type === 'RESULT' || message.type === 'CANCELLED' || message.type === 'ERROR') {
                activeRequestId = null;
            }
        };
        worker.onerror = (event) => {
            send({
                type: 'ERROR',
                requestId: activeRequestId,
                code: 'WORKER_RUNTIME',
                phase: 'worker',
                message: event?.message || 'The local parser failed while reading the file. Refresh the page and try again.'
            });
            destroyWorker();
        };
        parserWorker = worker;
        return worker;
    }

    window.addEventListener('message', (event) => {
        if (!isParentMessage(event)) return;
        const message = event.data || {};
        if (message.channel !== CHANNEL || !message.type) return;

        try {
            if (message.type === 'RESET') {
                destroyWorker();
                send({ type: 'RESET_DONE', requestId: message.requestId });
                return;
            }

            if (message.type === 'CANCEL') {
                if (parserWorker && message.requestId) {
                    parserWorker.postMessage({ type: 'CANCEL', requestId: message.requestId });
                }
                return;
            }

            const worker = createWorker();
            activeRequestId = message.requestId || null;

            if (message.type === 'INDEX_FILE') {
                worker.postMessage({
                    type: 'INDEX_FILE',
                    requestId: message.requestId,
                    file: message.file
                });
            } else if (message.type === 'PARSE_SCOPE') {
                worker.postMessage({
                    type: 'PARSE_SCOPE',
                    requestId: message.requestId,
                    scope: message.scope
                });
            } else if (message.type === 'PARSE_TEXT') {
                worker.postMessage({
                    type: 'PARSE_TEXT',
                    requestId: message.requestId,
                    rawLog: message.rawLog,
                    mode: message.mode,
                    scope: message.scope
                });
            }
        } catch (error) {
            send({
                type: 'ERROR',
                requestId: message.requestId,
                code: 'PARSER_START',
                phase: 'bridge',
                message: error?.message || 'The local parser could not start. Please refresh the page and try again.'
            });
            destroyWorker();
        }
    });

    send({ type: 'READY' });
}());
